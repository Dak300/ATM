import Model.*;

import com.google.gson.Gson;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;


import java.io.*;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Map;

public class ConvertFile {

    public void convert (String filePath){

        try {

            int a = 0;
            String b = null;
            //region Description
            String c = null;
            //endregion

            FileInputStream file = new FileInputStream(new File(filePath));


            XSSFWorkbook workbook = new XSSFWorkbook(file);

            XSSFSheet sheet = workbook.getSheetAt(0);

            Map<Object,Object> x = new LinkedHashMap<Object, Object>();

            ArrayList<String> arrayList = new ArrayList<String>();


           // LinkedList<String> linkedList = new LinkedList<JSONObject>();


          //  FileWriter writer = new FileWriter("/home/mura/Documents/GEO/main_branch.json");  // BRANCH
            FileWriter writer = new FileWriter("/home/mura/Documents/GEO/main_atmpt.json");  //ATM PT


            System.out.println(sheet.getPhysicalNumberOfRows());

            for (int i = sheet.getFirstRowNum() + 1 ; i<= sheet.getPhysicalNumberOfRows() - 1; i++){


                String str = null;

                MainModel mainModel = new MainModel();
                Address address = new Address();
                Cash cash = new Cash();
                Location location = new Location();
                Schedules schedules = new Schedules();
                Schedules schedules2 = new Schedules();

                Currencies currencies = new Currencies();

                Schedules[] schedules1 = null;  //new Schedules[]{schedules,schedules2};
                Workdays[] workdays = new Workdays[0];
                Workdays[] workdays1 = new Workdays[0];


                Simple simple = new Simple();
                Simple simple1 = new Simple();
                Simple simple2 = new Simple();
                Simple simple3 = new Simple();
                Simple simple4 = new Simple();

                Simple simple5 = new Simple();
                Simple simple6 = new Simple();
               // Simple simple7 = new Simple();

                mainModel.setAddress(address);
                mainModel.setCash(cash);
                mainModel.setLocation(location);

                mainModel.setIssuer(simple3);
                mainModel.setType(simple4);



                schedules.setWorkdays(workdays);
                schedules.setType(simple1);
                schedules.setWorkingMode(simple2);

                schedules2.setWorkdays(workdays1);
                schedules2.setType(simple5);
                schedules2.setWorkingMode(simple6);


                cash.setCurrencies(currencies);
                cash.setType(simple);


                Row row = sheet.getRow(i);

                if (row == null)
                    continue;


                for ( int j = row.getFirstCellNum(); j<= row.getLastCellNum(); j++ ){


                    Cell ce = row.getCell(j);

                    if ( j == 0){
                        if (ce.getStringCellValue().contains("ATM")){
                            mainModel.getType().setCode("ATM");
                            mainModel.getType().setName("банкомат");
                            schedules1 = new Schedules[]{schedules};
                        } else if (ce.getStringCellValue().contains("SST")){
                            mainModel.getType().setCode("SST");
                            mainModel.getType().setName("Платёжный терминал");
                            schedules1 = new Schedules[]{schedules};
                        } else if ( ce.getStringCellValue().contains("BR")){
                            mainModel.getType().setCode("BRANCH");
                            mainModel.getType().setName("отделение");
                            schedules1 = new Schedules[]{schedules,schedules2};
                        }
                        mainModel.setSchedules(schedules1);
                    }

                    if (j==1){
                        if (!isEmptyCell(ce)) {
                             str = " { \"_id\" : ObjectId(\"" + ce.getStringCellValue() + "\"),";
                           // mainModel.set_id(ce.getStringCellValue());
                           // mainModel.set_id(new ObjectId(ce.getStringCellValue()));
                        }
                    }


                    if (j == 2 ){
                        mainModel.getAddress().setCity(ce.getStringCellValue());
                    }

                    if (j== 3){
                        if (ce.getCellType() == Cell.CELL_TYPE_STRING){
                            mainModel.setCode(ce.getStringCellValue());
                        } else if ( ce.getCellType() == Cell.CELL_TYPE_NUMERIC){
                            mainModel.setCode(Integer.toString((int) ce.getNumericCellValue()));
                           // mainModel.setCode(String.valueOf(ce.getNumericCellValue()));
                        }
                    }

                    if (j== 4){
                        mainModel.getAddress().setDescription(ce.getStringCellValue());
                        mainModel.setName(ce.getStringCellValue());
                    }

                    if (j== 5){
                        mainModel.getAddress().setName(ce.getStringCellValue());
                    }
                    if (j== 6){
                        String s = ce.getStringCellValue().trim();
                        if ("IN-OUT".equals(s)) {
                            mainModel.getCash().getType().setName("Прием и выдача наличных");
                            mainModel.getCash().getType().setCode("IN-OUT");
                        } else if ("IN".equals(s)) {
                            mainModel.getCash().getType().setName("Прием наличных");
                            mainModel.getCash().getType().setCode("IN");
                        } else if ("OUT".equals(s)) {
                            mainModel.getCash().getType().setName("Выдача наличных");
                            mainModel.getCash().getType().setCode("OUT");
                        }
                    }
                    if (j== 8){
                           mainModel.getLocation().setType("Point");
                           String[] words = ce.getStringCellValue().split(",",2);
                       //    mainModel.getLocation().setCoordinates(new double[]{Double.parseDouble(words[0]), Double.parseDouble(words[1])});
                        // mainModel.getLocation().setCoordinates(new double[]{Double.parseDouble(words[1]), Double.parseDouble(words[0])});
                        mainModel.getLocation().setCoordinates(new double[]{Double.parseDouble(words[0]), Double.parseDouble(words[1])});
                    }
                    if (j== 9) {
                      /*  if (mainModel.getCash().getType().getCode() == "IN") {
                            mainModel.getCash().getCurrencies().setIn(new Simple[]{new Simple("KZT", "Тенге")});
                            mainModel.getCash().getCurrencies().setOut(new Simple[]{});
                        } else {
                            if (ce.getStringCellValue().contains("USD")) {
                                mainModel.getCash().getCurrencies().setIn(new Simple[]{new Simple("USD", "Доллары США"), new Simple("KZT", "Тенге")});
                                mainModel.getCash().getCurrencies().setOut(new Simple[]{new Simple("USD", "Доллары США"), new Simple("KZT", "Тенге")});
                            } else {
                                mainModel.getCash().getCurrencies().setIn(new Simple[]{new Simple("KZT", "Тенге")});
                                mainModel.getCash().getCurrencies().setOut(new Simple[]{new Simple("KZT", "Тенге")});
                            }
                        }*/
                      if (!isEmptyCell(ce)){
                          if (mainModel.getCash().getType().getCode() != "OUT") {
                              if (ce.getStringCellValue().contains("USD")) {
                                  mainModel.getCash().getCurrencies().setIn(new Simple[]{new Simple("USD", "Доллары США"), new Simple("KZT", "Тенге")});
                              } else {
                                  mainModel.getCash().getCurrencies().setIn(new Simple[]{new Simple("KZT", "Тенге")});
                              }
                          } else {
                              mainModel.getCash().getCurrencies().setIn(new Simple[]{});
                          }
                      }
                    }

                    if (j==10){
                        if (!isEmptyCell(ce)){
                            if (mainModel.getCash().getType().getCode() != "IN") {
                                if (ce.getStringCellValue().contains("USD")) {
                                    mainModel.getCash().getCurrencies().setOut(new Simple[]{new Simple("USD", "Доллары США"), new Simple("KZT", "Тенге")});
                                } else {
                                    mainModel.getCash().getCurrencies().setOut(new Simple[]{new Simple("KZT", "Тенге")});
                                }
                            } else {
                                mainModel.getCash().getCurrencies().setOut(new Simple[]{});
                            }
                        }
                    }


                    if (j== 11) {
                        if (mainModel.getType().getCode() != "BRANCH") {
                            schedules.getType().setCode("SIMPLE");
                            schedules.getType().setName("Режим работы");
                            if (ce.getStringCellValue().contains("24/7")) {
                                schedules.getWorkingMode().setCode("AROUND_THE_CLOCK");
                                schedules.getWorkingMode().setName("24/7");

                            } else {
                                workdays = new Workdays[7];
                                schedules.setWorkdays(workdays);
                                schedules.getWorkingMode().setCode("DAILY ");
                                schedules.getWorkingMode().setName(ce.getStringCellValue());
                            }
                        } else {
                            schedules.getType().setCode("PHYSICAL_PERSONS");
                            schedules.getType().setName("Физические лица");
                            if (ce.getStringCellValue().contains("SIX_DAYS")) {
                                schedules.getWorkingMode().setCode("SIX_DAYS");
                                schedules.getWorkingMode().setName("пн-сб");
                            } else if (ce.getStringCellValue().contains("FIVE_DAYS")) {
                                schedules.getWorkingMode().setCode("FIVE_DAYS");
                                schedules.getWorkingMode().setName("пн-пт");
                            } else if (ce.getStringCellValue().contains("SEVEN_DAYS")) {
                                schedules.getWorkingMode().setCode("SEVEN_DAYS");
                                schedules.getWorkingMode().setName("пн-вс");
                            }

                            workdays = new Workdays[7];
                            schedules.setWorkdays(workdays);

                        }
                    }

                    if (j==12){
                        if (schedules.getWorkingMode().getCode() != "AROUND_THE_CLOCK"){
                            if (!isEmptyCell(ce)){
                                String[] times = ce.getStringCellValue().split("-",2);
                                workdays[0]= new Workdays("monday",false,times[0],times[1]);
                                workdays[1]= new Workdays("tuesday",false,times[0],times[1]);
                                workdays[2]= new Workdays("wednesday",false,times[0],times[1]);
                                workdays[3]= new Workdays("thursday",false,times[0],times[1]);
                                workdays[4]= new Workdays("friday",false,times[0],times[1]);
                            }
                        }
                    }
                    if (j==13){
                        if (schedules.getWorkingMode().getCode() != "AROUND_THE_CLOCK"){
                            if (!isEmptyCell(ce)){
                                String[] times = ce.getStringCellValue().split("-",2);
                                workdays[5]= new Workdays("saturday",false,times[0],times[1]);
                            } else{
                                workdays[5]= new Workdays("saturday",true);
                            }
                        }
                    }
                    if (j==14){
                        if (schedules.getWorkingMode().getCode() != "AROUND_THE_CLOCK"){
                            if (!isEmptyCell(ce)){
                                String[] times = ce.getStringCellValue().split("-",2);

                                workdays[6]= new Workdays("sunday",false,times[0],times[1]);
                            } else {
                                workdays[6]= new Workdays("sunday",true);
                            }
                        }
                    }
                    if (j==15){
                        if (!isEmptyCell(ce)) {
                            if (mainModel.getType().getCode() == "BRANCH") {
                                if (!ce.getStringCellValue().contains("NO")) {
                                schedules2.getType().setCode("JURIDICAL_PERSONS");
                                schedules2.getType().setName("Юридические лица");
                                if (ce.getStringCellValue().contains("SIX_DAYS")) {
                                    schedules2.getWorkingMode().setCode("SIX_DAYS");
                                    schedules2.getWorkingMode().setName("пн-сб");
                                } else if (ce.getStringCellValue().contains("FIVE_DAYS")) {
                                    schedules2.getWorkingMode().setCode("FIVE_DAYS");
                                    schedules2.getWorkingMode().setName("пн-пт");
                                } else if (ce.getStringCellValue().contains("SEVEN_DAYS")) {
                                    schedules.getWorkingMode().setCode("SEVEN_DAYS");
                                    schedules.getWorkingMode().setName("пн-вс");
                                }
                                workdays1 = new Workdays[7];
                                schedules2.setWorkdays(workdays1);
                                } else {

                                    Schedules[] shedules3  = new Schedules[]{schedules};
                                    mainModel.setSchedules(shedules3);
                                }

                            } else {
                                    if ( ce.getStringCellValue().contains("true")) {
                                        mainModel.setHidden(true);
                                    }
                            }
                        }
                    }

                    if (j==16){
                        if (!isEmptyCell(ce)){
                            if (mainModel.getType().getCode() == "BRANCH"){
                            String[] times = ce.getStringCellValue().split("-",2);
                            workdays1[0]= new Workdays("monday",false,times[0],times[1]);
                            workdays1[1]= new Workdays("tuesday",false,times[0],times[1]);
                            workdays1[2]= new Workdays("wednesday",false,times[0],times[1]);
                            workdays1[3]= new Workdays("thursday",false,times[0],times[1]);
                            workdays1[4]= new Workdays("friday",false,times[0],times[1]);
                            workdays1[5]= new Workdays("saturday",true);
                            workdays1[6]= new Workdays("sunday",true);
                            }
                        }

                    }


                    if (j == 18){
                        if ( !isEmptyCell(ce)){
                            if (mainModel.getType().getCode() == "BRANCH" &&
                                    ce.getStringCellValue().contains("true")){
                                mainModel.setHidden(true);
                            }
                        }
                    }

                    if (j==19){
                        if ( !isEmptyCell(ce)){
                            if (mainModel.getType().getCode() == "BRANCH" &&
                                    ce.getStringCellValue().contains("SERVICES_FOR_LEGAL_PERSONS")){
                                mainModel.setServices(new Simple[]{new Simple("SERVICES_FOR_LEGAL_PERSONS",
                                        "Обслуживание юридических лиц")});
                            }
                        }
                    }




                }

                mainModel.getIssuer().setCode("ALFA");
                mainModel.getIssuer().setName("АО ДБ \"Альфа-Банк\"");

                Gson gson = new Gson();
                
                String json = null;
                
                if (str!=null){

                     json = str + gson.toJson(mainModel).substring(1);
                } else
                {
                    json = gson.toJson(mainModel);
                }
                

                System.out.println(json);
                writer.write(json);

                arrayList.add(json);

            }


         //   writer.write(String.valueOf(arrayList));
            writer.close();

/*
           ObjectMapper mapper = new ObjectMapper();
            mapper.writeValue(new File("/home/mura/example.json"), linkedList);
        //    String jsonFromMap = mapper.writeValueAsString(xx);
            file.close();
*/
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            System.out.println("Error ! File kaida ?");
        } catch (IOException e) {
            e.printStackTrace();
        }

    }


    boolean isEmptyCell (Cell cell){
        if (cell == null) {
            return true;
        }

        if (cell.getCellType() == Cell.CELL_TYPE_BLANK) {
            return true;
        }

        if (cell.getCellType() == Cell.CELL_TYPE_STRING && cell.getStringCellValue().trim().isEmpty()) {
            return true;
        }

        return false;
    }

}
