package Model;

public class Cash {
    private Simple type;
    private Currencies currencies;


    public Simple getType() {
        return type;
    }

    public void setType(Simple type) {
        this.type = type;
    }

    public Currencies getCurrencies() {
        return currencies;
    }

    public void setCurrencies(Currencies currencies) {
        this.currencies = currencies;
    }

    @Override
    public String toString() {
        return "Cash{" +
                "type=" + type +
                ", currencies=" + currencies +
                '}';
    }
}
