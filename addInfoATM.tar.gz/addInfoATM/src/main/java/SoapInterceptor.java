import org.apache.cxf.interceptor.LoggingInInterceptor;

public class SoapInterceptor extends LoggingInInterceptor {

}
