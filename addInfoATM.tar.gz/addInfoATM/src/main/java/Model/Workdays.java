package Model;


public class Workdays
{
    private String dayOfWeek;

    private Boolean isHoliday;

    private String opensAt;

    private String closesAt;


    public String getDayOfWeek() {
        return dayOfWeek;
    }

    public void setDayOfWeek(String dayOfWeek) {
        this.dayOfWeek = dayOfWeek;
    }

    public Boolean getHoliday() {
        return isHoliday;
    }

    public void setHoliday(Boolean holiday) {
        isHoliday = holiday;
    }

    public String getOpensAt() {
        return opensAt;
    }

    public void setOpensAt(String opensAt) {
        this.opensAt = opensAt;
    }

    public String getClosesAt() {
        return closesAt;
    }

    public void setClosesAt(String closesAt) {
        this.closesAt = closesAt;
    }

    public Workdays(String dayOfWeek, Boolean isHoliday, String opensAt, String closesAt) {
        this.dayOfWeek = dayOfWeek;
        this.isHoliday = isHoliday;
        this.opensAt = opensAt;
        this.closesAt = closesAt;
    }

    public Workdays(String dayOfWeek, Boolean isHoliday) {
        this.dayOfWeek = dayOfWeek;
        this.isHoliday = isHoliday;
    }

    @Override
    public String toString() {
        return "Workdays{" +
                "dayOfWeek='" + dayOfWeek + '\'' +
                ", isHoliday=" + isHoliday +
                ", opensAt='" + opensAt + '\'' +
                ", closesAt='" + closesAt + '\'' +
                '}';
    }
}
