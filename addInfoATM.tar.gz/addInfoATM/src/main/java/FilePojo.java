public class FilePojo {


    private int id;
    private String city;
    private int atm;
    private  String place;
    private String place_atm;
    private String type_off;
    private String times;


    public int getAtm() {
        return atm;
    }

    public void setAtm(int atm) {
        this.atm = atm;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }



    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }



    public String getPlace() {
        return place;
    }

    public void setPlace(String place) {
        this.place = place;
    }

    public String getPlace_atm() {
        return place_atm;
    }

    public void setPlace_atm(String place_atm) {
        this.place_atm = place_atm;
    }

    public String getType_off() {
        return type_off;
    }

    public void setType_off(String type_off) {
        this.type_off = type_off;
    }

    public String getTimes() {
        return times;
    }

    public void setTimes(String times) {
        this.times = times;
    }


    @Override
    public String toString() {
        return "FilePojo{" +
                "id=" + id +
                ", city='" + city + '\'' +
                ", atm='" + atm + '\'' +
                ", place='" + place + '\'' +
                ", place_atm='" + place_atm + '\'' +
                ", type_off='" + type_off + '\'' +
                ", times='" + times + '\'' +
                '}';
    }
}
