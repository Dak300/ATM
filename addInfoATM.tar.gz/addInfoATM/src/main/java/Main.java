
import com.sun.org.apache.xpath.internal.operations.Bool;
import kz.alfabank.soa.payterm.SoaException_Exception;
import org.apache.cxf.wsdl11.SOAPBindingUtil;

import java.io.IOException;



public class Main {


    //System.getenv("EX_FILEPATH");
  //  private static String filePath  = "/home/mura/Documents/GEO/main_branch.xlsx";   //  BRANCH
    private static String filePath  = "/home/mura/Documents/GEO/main_atmpt.xlsx";   //  ATM PT

    public static void main(String[] args) throws IOException {

        ConvertFile convertFile = new ConvertFile();
        convertFile.convert(filePath);
/*

        String txtMess = "KZ424252525;AccDepoAB;920202300971";
        String[] txtMessArray ;
        txtMessArray = txtMess.split(";");
        String cliAcc = txtMessArray[0];
        String opertype = txtMessArray[1];
        String taxcode = txtMessArray[2];*/
/*
        System.out.println(cliAcc + "\n" + opertype + "\n" + taxcode);*//*


        for ( String str : txtMessArray){
            System.out.println(str);
        }

*/

/*

        RestExample restExample = new RestExample();
        restExample.doPost();*/

    /*  WSatm wSatm = new WSatm();
        try {
            wSatm.atmDepos();
        } catch (SoaException_Exception e) {
            System.out.println(e.getFaultInfo().getReqid() +
                    e.getFaultInfo().getCode() + e.getFaultInfo().getMessage());
        }*/



  //Удача – очень жестокая богиня, которая никогда никому не помогает постоянно.
      //  Напротив, она приводит к краху почти любого человека, которого ранее незаслуженно осыпала золотом

/*
        Разве не мудро наслаждаться жизнью, пока мы живы и над нами светит солнце? Ведь горести и печали придут сами, когда нам придется отправиться в мир теней.*/




/*
        Я расскажу тебе то, что ты хочешь знать, ибо я уже стар, а старые языки любят поболтать.
        А когда молодые люди приходят к старикам за советом, они получают мудрость, накопленную годами.
        Но слишком часто молодость полагает, что старости ведома только мудрость прошедших лет, которая для молодых бесполезна.
        Запомни: солнце, что светит сегодня, – это то же самое солнце, что светило и тогда, когда родился твой отец,
        и будет светить, когда последний из твоих правнуков уйдет в мир иной.
*/


    }
}
