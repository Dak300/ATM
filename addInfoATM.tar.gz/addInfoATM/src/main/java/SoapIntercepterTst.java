import org.apache.cxf.interceptor.Fault;
import org.apache.cxf.message.Message;
import org.apache.cxf.phase.AbstractPhaseInterceptor;
import org.apache.cxf.phase.Phase;
import org.apache.cxf.phase.PhaseInterceptorChain;
import org.apache.http.entity.StringEntity;

import java.util.Set;
import java.util.SortedSet;


public class SoapIntercepterTst extends AbstractPhaseInterceptor<Message> {


    public SoapIntercepterTst() {
        super(Phase.POST_STREAM);
    }

    @Override
    public void handleMessage(Message message) throws Fault {
        if (message != null){
            System.out.println(message.toString());
            System.out.println(message.getExchange().toString());
            message.getExchange().put("123", String.class);
        }

    }
}
