import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.cxf.configuration.jsse.TLSClientParameters;

import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.math.BigDecimal;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;

public class RestExample {


    public void doPost (){
        try {
            URL url = new URL("https://vserver035.alfa-bank.kz/payterm-atm/cashin");
            try {
                try {
                    disableSSLValidation();
                } catch (NoSuchAlgorithmException e) {
                    e.printStackTrace();
                } catch (KeyManagementException e) {
                    e.printStackTrace();
                }
                PaymentAtmReq paymentAtmReq = new PaymentAtmReq();
                paymentAtmReq.setReqID("3214414141");
                paymentAtmReq.setSystemcode("ATM");
                paymentAtmReq.setTerminal("04004");
                paymentAtmReq.setId("324141");
                paymentAtmReq.setOpertype("AccDepoAB");
                paymentAtmReq.setAmount(BigDecimal.valueOf(370000));
                paymentAtmReq.setSaccount("KZ069471398000304941");
                paymentAtmReq.setDaccount("KZ709470398010467305");

                ObjectMapper objectMapper = new ObjectMapper();

                String jsonStr = objectMapper.writeValueAsString(paymentAtmReq);

                HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
                httpURLConnection.setDoOutput(true);
                httpURLConnection.setRequestMethod("POST");
                httpURLConnection.setRequestProperty("Content-Type", "application/json");
                httpURLConnection.setRequestProperty("Accept", "application/json");

                DataOutputStream dataOutputStream = new DataOutputStream(httpURLConnection.getOutputStream());
                System.out.println(jsonStr);
              // dataOutputStream.write(paymentAtmReq.toString().getBytes());
              //  dataOutputStream.writeChars(paymentAtmReq.toString());
                dataOutputStream.writeChars(jsonStr);

                Integer responceCode = httpURLConnection.getResponseCode();

                System.out.println(" RESPONCE " + responceCode);

                BufferedReader bufferedReader;

                if (responceCode > 199 && responceCode < 300){
                    bufferedReader = new BufferedReader(new InputStreamReader(httpURLConnection.getInputStream()));
                } else {
                    bufferedReader = new BufferedReader(new InputStreamReader(httpURLConnection.getErrorStream()));
                }

                //System.out.println(bufferedReader.readLine());

                StringBuilder content = new StringBuilder();

                String line;

                while((line = bufferedReader.readLine())!= null){
                    System.out.println(line);
                    content.append(line).append("\n");
                }

                System.out.println(content.toString());

                PaymentAtmResp paymentAtmResp = objectMapper.readValue(content.toString(),PaymentAtmResp.class);

                System.out.println(paymentAtmResp.getCode());
                System.out.println(paymentAtmResp.getMessage());




            } catch (IOException e) {
                e.printStackTrace();
            }


        } catch (MalformedURLException e) {
            e.printStackTrace();
        }


    }

    public void disableSSLValidation () throws NoSuchAlgorithmException, KeyManagementException {

        TrustManager[] trustAllCerts = new TrustManager[]{new X509TrustManager() {
            public java.security.cert.X509Certificate[] getAcceptedIssuers() {
                return new java.security.cert.X509Certificate[0];
            }

            public void checkClientTrusted(java.security.cert.X509Certificate[] certs, String authType) {
            }

            public void checkServerTrusted(java.security.cert.X509Certificate[] certs, String authType) {
            }
        }};

        SSLContext sslContext = SSLContext.getInstance("TLSv1.2");
        sslContext.init(null, trustAllCerts, new java.security.SecureRandom());
        HttpsURLConnection.setDefaultSSLSocketFactory(sslContext.getSocketFactory());

    }
}
