package Model;




import java.util.Arrays;

public class MainModel {


    private String code;
    private Address address;
    private Cash cash;
    private Simple issuer;
    private Location location;
    private String name;
    private Schedules[] schedules;
    private Simple type;
    private Simple[] services;
    private Boolean isHidden;



    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public Address getAddress() {
        return address;
    }

    public void setAddress(Address address) {
        this.address = address;
    }

    public Cash getCash() {
        return cash;
    }

    public void setCash(Cash cash) {
        this.cash = cash;
    }

    public Simple getIssuer() {
        return issuer;
    }

    public void setIssuer(Simple issuer) {
        this.issuer = issuer;
    }

    public Location getLocation() {
        return location;
    }

    public void setLocation(Location location) {
        this.location = location;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }



    public Simple getType() {
        return type;
    }

    public void setType(Simple type) {
        this.type = type;
    }


    public Schedules[] getSchedules() {
        return schedules;
    }

    public void setSchedules(Schedules[] schedules) {
        this.schedules = schedules;
    }

    public Simple[] getServices() {
        return services;
    }

    public void setServices(Simple[] services) {
        this.services = services;
    }

    public Boolean getHidden() {
        return isHidden;
    }

    public void setHidden(Boolean hidden) {
        isHidden = hidden;
    }


    @Override
    public String toString() {
        return "MainModel{" +
                "code='" + code + '\'' +
                ", address=" + address +
                ", cash=" + cash +
                ", issuer=" + issuer +
                ", location=" + location +
                ", name='" + name + '\'' +
                ", schedules=" + Arrays.toString(schedules) +
                ", type=" + type +
                ", services=" + Arrays.toString(services) +
                ", isHidden=" + isHidden +
                '}';
    }
}
