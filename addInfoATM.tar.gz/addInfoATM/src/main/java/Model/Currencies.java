package Model;

import java.util.Arrays;

public class Currencies {
    private Simple[] in;
    private Simple[] out;

    public Simple[] getIn() {
        return in;
    }

    public void setIn(Simple[] in) {
        this.in = in;
    }

    public Simple[] getOut() {
        return out;
    }

    public void setOut(Simple[] out) {
        this.out = out;
    }

    @Override
    public String toString() {
        return "currencies{" +
                "in=" + Arrays.toString(in) +
                ", out=" + Arrays.toString(out) +
                '}';
    }
}
