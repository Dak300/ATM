
import kz.alfabank.integration.exception.ServiceFaultException;
import kz.alfabank.soa.payterm.*;
import org.apache.cxf.configuration.jsse.TLSClientParameters;
import org.apache.cxf.endpoint.Client;
import org.apache.cxf.feature.StaxTransformFeature;
import org.apache.cxf.frontend.ClientProxy;
import org.apache.cxf.interceptor.Interceptor;
import org.apache.cxf.interceptor.transform.TransformOutInterceptor;
import org.apache.cxf.message.Message;
import org.apache.cxf.phase.Phase;
import org.apache.cxf.phase.PhaseInterceptorChain;
import org.apache.cxf.transport.http.HTTPConduit;
import org.apache.http.client.HttpClient;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.impl.client.HttpClientBuilder;
import org.mongodb.morphia.mapping.Serializer;
import kz.alfabank.integration.interceptors.SoapInterceptor;
import javax.net.ssl.*;
import javax.xml.bind.JAXBException;
import javax.xml.bind.SchemaOutputResolver;
import javax.xml.namespace.QName;
import javax.xml.ws.BindingProvider;
import javax.xml.ws.Endpoint;
import javax.xml.ws.WebServiceFeature;
import javax.xml.ws.soap.SOAPFaultException;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.Socket;
import java.net.URL;
import java.security.*;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.Collections;
import java.util.Map;

public class WSatm  {



    public void atmDepos () throws SoaException_Exception {

        String stl = "AccDepoAb;KZ4342343242424";


       /* String x = stl.split(";",2)[0];

        String x2 = stl.split(";",2)[1];*/

        String x3 = stl.substring(stl.indexOf(";")+1);
        String x4 = stl.substring(0 ,stl.indexOf(";"));

        System.out.println(x3);
        System.out.println(x4);






        String wsdlLocation = "https://vserver035.alfa-bank.kz/payterm-atm/soa/payterm-atm/payterm-atm.wsdl";

        try {
            SslUtil.ensureSslCertIsInKeystore("startssl", new FileInputStream("src/main/java/certificate/vserver035.alfa-bank.kz.crt"));
        } catch (KeyStoreException e) {
            e.printStackTrace();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        } catch (CertificateException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }


        try {

            TLSClientParameters tlsParams = null;
            /*try {
               tlsParams = disableSSLValidation();
            } catch (NoSuchAlgorithmException | KeyManagementException e) {
                e.printStackTrace();
            }*/
            URL url = new URL(wsdlLocation);

            PayTermService payTermService = new PayTermService(url);

            PayTermServicePortType payTermServicePortType = payTermService.getPayTermServicePort();

            BindingProvider bindingProvider = (BindingProvider) payTermServicePortType;

            bindingProvider.getRequestContext().put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY,
                        "https://vserver035.alfa-bank.kz/payterm-atm/soa/payterm-atm");

            Client client = ClientProxy.getClient(payTermServicePortType);
            //client.getInInterceptors().add(new SoapIntercepterTst());

            HTTPConduit httpConduit = (HTTPConduit) client.getConduit();
            httpConduit.setTlsClientParameters(tlsParams);


            CreateFinTx createFinTx = new CreateFinTx();
            FinTxRq finTxRq = new FinTxRq();
            finTxRq.setSystemcode("ATM");
            finTxRq.setReqid("414111");
            finTxRq.setTerminal("03004");
            finTxRq.setId("543634633");
            finTxRq.setOpertype("AccDepoAB");
            finTxRq.setAmount(100000);
            finTxRq.setSaccount("KZ069471398000304941");
            finTxRq.setDaccount("KZ709470398010467305");
            createFinTx.setFinTxRq(finTxRq);
            FinTxRp finTxRp = new FinTxRp();

            CreateFinTxResponse createFinTxResponse = new CreateFinTxResponse();
            createFinTxResponse.setFinTxRp(finTxRp);


            try {


                createFinTxResponse = payTermServicePortType.createFinTx(createFinTx);

            } catch(ServiceFaultException sv){
                System.out.println(sv.getCode());
                System.out.println(sv.getReqid());
            }
              catch (RuntimeException rn) {
                System.out.println("ssssss22222222");
            } catch (SoaException_Exception e) {
                System.out.println(e.getMessage());
            } catch (Exception ex) {

                System.out.println("wwwwwwwwwwwwwwwwwww");

            }

            System.out.println(createFinTxResponse.getFinTxRp());
            System.out.println(createFinTxResponse.getFinTxRp().getCode());
            System.out.println(createFinTxResponse.getFinTxRp().getReqid());
            System.out.println(createFinTxResponse.getFinTxRp().getFee());


        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
    }

    /*
       Disable SSL validation
     */

    public TLSClientParameters  disableSSLValidation ( ) throws NoSuchAlgorithmException, KeyManagementException {

         TrustManager[] trustAllCerts = new TrustManager[]{new X509TrustManager() {
             public java.security.cert.X509Certificate[] getAcceptedIssuers() {
                 return new java.security.cert.X509Certificate[0];
             }

             public void checkClientTrusted(java.security.cert.X509Certificate[] certs, String authType) {
             }

             public void checkServerTrusted(java.security.cert.X509Certificate[] certs, String authType) {
             }
         }};

         SSLContext sslContext = SSLContext.getInstance("TLSv1.2");
         sslContext.init(null, trustAllCerts, new java.security.SecureRandom());
         HttpsURLConnection.setDefaultSSLSocketFactory(sslContext.getSocketFactory());

         TLSClientParameters tlsParams = new TLSClientParameters();
         tlsParams.setTrustManagers(trustAllCerts);
         tlsParams.setDisableCNCheck(true);
          return  tlsParams;
    }

}
