package Model;

import java.util.Arrays;

public class Schedules {
    private Simple type;
    private Simple workingMode;
    private Workdays[] workdays;

    public Simple getType() {
        return type;
    }

    public void setType(Simple type) {
        this.type = type;
    }

    public Simple getWorkingMode() {
        return workingMode;
    }

    public void setWorkingMode(Simple workingMode) {
        this.workingMode = workingMode;
    }

    public Workdays[] getWorkdays() {
        return workdays;
    }

    public void setWorkdays(Workdays[] workdays) {
        this.workdays = workdays;
    }

    @Override
    public String toString() {
        return "Schedules{" +
                "type=" + type +
                ", workingMode=" + workingMode +
                ", workdays=" + Arrays.toString(workdays) +
                '}';
    }
}
